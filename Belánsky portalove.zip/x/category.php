 <!DOCTYPE html>
<html lang="en">
 <?php  include_once "parts/header.php";

 if(isset($db)) {
     $articles = $db->getAllArticles();
 } else {
     $db = new stdClass();
     $articles = [];
 }?>
  <body>
  


  <?php include_once "parts/nav.php"; ?>
    
    
    <div class="py-5 bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <span>Category</span>
            <h3>PC Games Category</h3>
            <p>Category description here.. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam error eius quo, officiis non maxime quos reiciendis perferendis doloremque maiores!</p>
          </div>
        </div>
      </div>
    </div>

      <div class="site-section bg-light">
          <div class="container">
              <div class="row align-items-stretch retro-layout-2">


                  <div class="row tm-row">
                      <?php
                      $i = 0;
                      foreach ($articles as $article) {
                          include "parts/article.php";
                          $i++;
                      }
                      ?>
                  </div>
              </div>
          </div>
      </div>




      <?php  include_once "parts/ss.php";?>
      <?php  include_once "parts/footer.php";?>


    
  </body>
</html>