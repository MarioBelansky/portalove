 <!DOCTYPE html>
<html lang="en">
 <?php  include_once "parts/header.php"; ?>
  <body>
  <?php include_once "parts/nav.php";
  if(!isset($db)) {
      $db = new stdClass();
  }
  $id = $_GET['id'];
  $articleDetails = $db->getArticle($id);
  $comments = $db->getComments($id);

  if(!isset($menus)) {
      $menus = [];
  }
  ?>

  <?php
  if($articleDetails) {
  ?>
    
    
    <div class="site-cover site-cover-sm same-height overlay single-page" style="background-image: url('<?php echo $articleDetails['image']; ?>');">
      <div class="container">
        <div class="row same-height justify-content-center">
          <div class="col-md-12 col-lg-10">
            <div class="post-entry text-center">
              <span class="post-category text-white bg-success mb-3"><?php echo $articleDetails['category']; ?></span>
              <h1 class="mb-4"><a href="#"><?php echo $articleDetails['title']; ?></a></h1>
              <div class="post-meta align-items-center text-center">
                <figure class="author-figure mb-0 mr-3 d-inline-block"><img src="<?php echo $articleDetails['pimage']; ?>" alt="Image" class="img-fluid"></figure>
                <span class="d-inline-block mt-1">By <?php echo $articleDetails['username']; ?></span>
                <span>&nbsp;-&nbsp; <?php echo date("d.m.Y", strtotime($articleDetails['created_at'])); ?></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <section class="site-section py-lg">
      <div class="container">
        
        <div class="row blog-entries element-animate">

          <div class="col-md-12 col-lg-8 main-content">
            
            <div class="post-content-body">
            <p> <?php echo $articleDetails['content']; ?> </p>
            </div>

            
            <div class="pt-5">
              <p>Categories:  <a href="#"><?php echo $articleDetails['category']; ?></a></p>
            </div>

             <!-- comment-list -->
            <div class="pt-5">


              <h3 class="mb-5">Comments</h3>
              <ul class="comment-list">
                <li class="comment">
                    <?php
                    if(count($comments) > 0) {
                        foreach ($comments as $comment) {
                            include "parts/comment.php";
                        }
                    } else {
                        echo "Ziadne komentare";
                    }
                    ?>





              <div class="comment-form-wrap pt-5">
                <h3 class="mb-5">Leave a comment</h3>
                <form action="add-post-comment.php" method="post" class="p-5 bg-light">

                    <div class="form-group">
                    <label for="name">Name *</label>
                        <input class="form-control" name="name" type="text" placeholder="Name">
                  </div>

                    <div class="form-group">
                    <label for="email">Email *</label>
                        <input class="form-control" name="email" type="text" placeholder="E-mail">
                  </div>

                    <div class="form-group">
                    <label for="message">Message</label>
                        <textarea class="form-control" name="content" rows="6"></textarea>
                  </div>

                    <div class="form-group">
                        <input type="hidden" name="post_id" value="<?php echo $id; ?>">
                        <input type="submit" name="submit" class="form-control" value="Submit">
                    </div>



                </form>
              </div>
            </div>

          </div>
          <!-- END comment-list -->

          <!-- END main-content -->

          <div class="col-md-12 col-lg-4 sidebar">
            <div class="sidebar-box search-form-wrap">
              <form action="#" class="search-form">
                <div class="form-group">
                  <span class="icon fa fa-search"></span>
                  <input type="text" class="form-control" id="s" placeholder="Type a keyword and hit enter">
                </div>
              </form>
            </div>
            <!-- END sidebar-box -->
            <div class="sidebar-box">
              <div class="bio text-center">
                <img src="<?php echo $articleDetails['pimage']; ?>" alt="Image Placeholder" class="img-fluid mb-5">
                <div class="bio-body">
                  <h2><?php echo $articleDetails['username']; ?></h2>
                    <p><a href="#" class="btn btn-primary btn-sm rounded px-4 py-2">Read my bio</a></p>
                </div>
              </div>
            </div>

            <!-- END sidebar-box -->  
            <div class="sidebar-box">
              <h3 class="heading">Popular Posts</h3>
              <div class="post-entry-sidebar">
                <ul>
                  <li>
                    <a href="">
                      <img src="images/img_1.jpg" alt="Image placeholder" class="mr-4">
                      <div class="text">
                        <h4>There’s a Cool New Way for Men to Wear Socks and Sandals</h4>
                        <div class="post-meta">
                          <span class="mr-2">March 15, 2018 </span>
                        </div>
                      </div>
                    </a>
                  </li>

              </div>
            </div>
            <!-- END sidebar-box -->

            <div class="sidebar-box">
              <h3 class="heading">Categories</h3>
              <ul class="categories">
                  <?php
                  foreach ($menus as $number => $menu) {
                      ?>
                      <li><a href="<?php echo $menu['path']; ?>"><?php echo $menu['name']; ?></a></li>
                      <?php
                  }
                  ?>

              </ul>
            </div>
            <!-- END sidebar-box -->

            <div class="sidebar-box">
              <h3 class="heading">Tags</h3>
              <ul class="tags">
                <li><a href="#">Gaming</a></li>
                <li><a href="#">Adventure</a></li>
                <li><a href="#">Strategy</a></li>
                <li><a href="#">Survival</a></li>
                <li><a href="#">Open-world</a></li>
                <li><a href="#">Sandbox</a></li>
                <li><a href="#">Multiplayer</a></li>
                <li><a href="#">Building</a></li>
                <li><a href="#">Co-op</a></li>
                <li><a href="#">RPG</a></li>
                <li><a href="#">PvP</a></li>
                <li><a href="#">Base Building</a></li>
              </ul>
            </div>
          </div>
          <!-- END sidebar -->

        </div>
      </div>
    </section>
<?php
  } else {
      echo "Zadany clanok neexistuje";
  }
  include_once "parts/footer.php";?>


    
  </body>
</html>