<?php
if(!isset($id)) {
    $id = 1;
}
if(!isset($db)) {
    $db = new stdClass();
}
if(!isset($comment)) {
    $comment = [];
}
?>




<li class="comment">
    <div class="vcard">
        <img src="<?php echo $comment['pimage']; ?>" alt="Image placeholder">
    </div>
    <div class="comment-body">
        <h3><?php echo $comment['username']; ?></h3>
        <div class="meta"><?php echo date("d.m.Y", strtotime($comment['created_at'])); ?></div>
        <p><?php echo $comment['content']; ?></p>
        <p>
            <a href="delete-post-comment.php?comment-id=<?php echo $comment['id'];?>&post-id=<?php echo $id; ?>" class="reply rounded">Delete</a>
            <a href="update-post-comment.php?comment-id=<?php echo $comment['id'];?>&post-id=<?php echo $id; ?>" class="reply rounded">Update</a></p>
    </div>
