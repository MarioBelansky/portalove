<?php
if(!isset($article)) {
    $article = [];
}
if(!isset($i)) {
    $i = 0;
}
if(!isset($db)) {
    $db = new stdClass();
}
?>

<div class="col-lg-4 mb-4">
    <div class="entry2">
        <a href="single.php?id=<?php echo $article['id']; ?>"><img src="<?php echo $article['image']; ?>" alt="Image" class="img-fluid rounded"></a>
        <div class="excerpt">
            <span class="post-category text-white bg-success mb-3"><?php echo $article['category']; ?></span>

            <h2><a href="single.php?id=<?php echo $article['id']; ?>"><?php echo $article['title']; ?></a></h2>
            <div class="post-meta align-items-center text-left clearfix">
                <figure class="author-figure mb-0 mr-3 d-inline-block"><img src="<?php echo $article['pimage']; ?>" alt="Image" class="img-fluid"></figure>
                <span class="d-inline-block mt-1">By <a href="#"><?php echo $article['username']; ?></a></span>
                <span><?php echo date("d.m.Y", strtotime($article['created_at'])); ?></span>
            </div>

            <p><?php echo $article['perex']; ?></p>

            <span><?php echo $db->countArticleComments($article['id']); ?> comments</span>
            <p><a href="single.php?id=<?php echo $article['id']; ?>">Read More</a></p>
        </div>
    </div>
</div>

